<?php
/**
 * The template for displaying archive pages.
 *
 * Learn more: https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package storefront
 */

get_header(); ?>
<div class="logo"> 
 <a href="https://www.como-mola.com/"> <img src="https://shop.spreadshirt.es/100634714/shopData/images/logo/LogoTiendav2_ruvuvs.png" alt="Como Mola Store"></a> 
</div> <div class="menu" style="padding-bottom: 15px;"> 
 <ul class="menusup" > 
  <li class="dropdown"> <p class="dropbtn">Hombre<span class="flecha">▼</span></p> 
   <div class="dropdown-content"> 
    <a href="https://www.como-mola.com/tienda/hombre/">Todo</a> 
    <a href="https://www.como-mola.com/tienda/hombre/camisetas-originales/">Camisetas</a> 
    <a href="https://www.como-mola.com/tienda/hombre/sudaderas-personalizadas/">Sudaderas</a> 
    <a href="https://www.como-mola.com/tienda/hombre/camiseta-manga-larga/">Manga Larga</a> 
    <a href="https://www.como-mola.com/tienda/hombre/polos/">Polos</a> 
    <a href="https://www.como-mola.com/tienda/hombre/camiseta-de-tirantes/">Camisetas de Tirantes</a> 
    <a href="https://www.como-mola.com/tienda/hombre/camisetas-ecologicas-para-hombre/">Camisetas Ecológicas</a> 
    <a href="https://www.como-mola.com/tienda/hombre/ropa-deportiva-hombre/">Ropa Deportiva</a> 
    <a href="https://www.como-mola.com/tienda/hombre/nuevos-productos-hombre">Nuevos Productos</a> 
   </div> </li> 
  <li class="dropdown"> <p class="dropbtn">Mujer<span class="flecha">▼</span></p> 
   <div class="dropdown-content"> 
    <a href="https://www.como-mola.com/tienda/mujer/">Todo</a> 
    <a href="https://www.como-mola.com/tienda/mujer/camisetas-originales-mujer/">Camisetas</a> 
    <a href="https://www.como-mola.com/tienda/mujer/sudaderas-personalizadas-mujer/">Sudaderas</a> 
    <a href="https://www.como-mola.com/tienda/mujer/camiseta-manga-larga-mujer/">Manga Larga</a> 
    <a href="https://www.como-mola.com/tienda/mujer/polos-mujer/">Polos</a> 
    <a href="https://www.como-mola.com/tienda/mujer/tops-mujer/">Tops</a> 
    <a href="https://www.como-mola.com/tienda/mujer/camisetas-ecologicas-para-mujer/">Camisetas Ecológicas</a> 
    <a href="https://www.como-mola.com/tienda/mujer/ropa-deportiva-mujer/">Ropa Deportiva</a> 
   </div> </li> 
  <li class="dropdown"> <p class="dropbtn">Niños y Bebés<span class="flecha">▼</span></p> 
   <div class="dropdown-content"> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/">Todo</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/camisetas-originales-ninos/">Camisetas Niños</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/camisetas-originales-bebes/">Camisetas Bebés</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/bodies-bebe/">Bodies Bebé</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/accesorios-ninos-bebes/">Accesorios</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/baberos-bebe/">Baberos</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/gorra-bebes/">Gorra Bebés</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/bodies-organicos-bebes/">Bodies Orgánicos</a> 
    <a href="https://www.como-mola.com/tienda/ninos-y-bebes/nuevos-productos-ninos-bebes/">Nuevos Productos</a> 
   </div> </li> 
  <li class="dropdown"> <p class="dropbtn">Accesorios<span class="flecha">▼</span></p> 
   <div class="dropdown-content"> 
    <a href="https://www.como-mola.com/tienda/accesorios/">Todo</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/mascarillas-personalizadas/">Mascarillas Personalizadas</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/tazas/">Tazas y Accesorios</a> 	   
    <a href="https://www.como-mola.com/tienda/accesorios/gorras-gorros/">Gorras y gorros</a>
    <a href="https://www.como-mola.com/tienda/accesorios/carcasas-iphone/">Carcasas iPhone</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/carcasas-samsung/">Carcasas Samsung</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/bolsas-mochilas/">Bolsas y Mochilas</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/delantales/">Delantales</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/fundas-cojin/">Fundas de Cojín</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/chapas/">Chapas</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/peluches/">Peluches</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/alfombrillas-raton/">Alfombrillas de ratón</a>
    <a href="https://www.como-mola.com/tienda/accesorios/bufanda/">Bufanda</a> 
    <a href="https://www.como-mola.com/tienda/accesorios/nuevos-productos-accesorios/">Nuevos Productos</a> 
   </div> </li> 
  <li class="dropdown"> <p class="dropbtn">Personalízatelo<span class="flecha">▼</span></p> 
   <div class="dropdown-content"> 
    <a href="https://www.como-mola.com/tienda/diseno-personalizado/ropa-y-accesorios-personalizados/">Todo</a> 
	<a href="https://www.como-mola.com/tienda/diseno-personalizado/crear-mascarilla-personalizada/">Mascarilla</a> 
    <a href="https://www.como-mola.com/tienda/diseno-personalizado/camisetas-personalizadas-hombre/">Camisetas Chico</a> 
    <a href="https://www.como-mola.com/tienda/diseno-personalizado/camisetas-personalizadas-mujer/">Camisetas Chica</a>
    <a href="https://www.como-mola.com/tienda/diseno-personalizado/body-bebe-personalizado/">Body para bebé</a>
    <a href="https://www.como-mola.com/tienda/diseno-personalizado/body-personalizado-manga-larga/">Body manga larga</a>
	<a href="https://www.como-mola.com/tienda/diseno-personalizado/taza-personalizada/">Taza Blanca</a> 
    <a href="https://www.como-mola.com/tienda/diseno-personalizado/tazas-personalizadas-de-colores/">Taza de Color</a>
	<a href="https://www.como-mola.com/tienda/diseno-personalizado/gorra-de-colores-personalizada/">Gorras de colores</a>
	  </div></li> 
  <li class="dropdown"><a href="https://www.como-mola.com/tienda/nuestros-disenos/">Todos los diseños</a></li>
  <li><a href="https://www.como-mola.com/blog/">BLOG</a></li> 
  <li class="dropdown"><a href="https://www.como-mola.com/#!/about">Nosotros</a></li> 
 </ul> 
</div>
	<div id="primary" class="content-area">
		<main id="main" class="site-main" role="main" style="text-align:center;">
			<?php while (have_posts()) : the_post(); ?>
			<div class="entradas">
			<div class="excerpt-post">
				<div class="img-destacada"><a href="<?php the_permalink()?>" style="color:#3e3e3e"><?php the_post_thumbnail( 'medium' ); ?></a></div>
				<h2 id="post-<?php the_ID(); ?>" style="text-align:center;font-weight: bold;">
						<a href="<?php the_permalink() ?>" style="color:#3e3e3e" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a></h2>
				<div class="entry">
					<a href="<?php the_permalink()?>" style="color:#3e3e3e"><?php the_excerpt('Continue Reading...') ?></a>
				</div>
			<!--
			-->
			</div>
							</div>
			<?php endwhile; ?>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
do_action( 'storefront_sidebar' );
get_footer();
